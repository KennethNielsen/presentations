def perform_subtask0():
    print 'Hello'

def perform_subtask1():
    print 'world'


def perform_task():
    perform_subtask0()
    perform_subtask1()

perform_task()
